#include <stdio.h>
#include "queuelinked.h"
#include "charmachine.h"
char currentChar;
boolean EOP;


int main(){
    Queue q1, q2, q3;
    CreateQueue(&q1);
    CreateQueue(&q2);
    CreateQueue(&q3);
    boolean next= false;
    int n= 0;
    START();
    while(!EOP){
        if(currentChar == ','){
            for(int i= 1; i<=n; i++){
                enqueue(&q3, i);
            }
            next= true;
        }else{
            if(next){
                if(currentChar == 'B'){
                    enqueue(&q2, 0);
                }else if(currentChar == 'K'){
                    enqueue(&q2, 1);
                }
            }else{
                if(currentChar == 'B'){
                    enqueue(&q1, 0);
                }else if(currentChar == 'K'){
                    enqueue(&q1, 1);
                }
                n++;
            }
        }
        ADV();
    }
    // boolean cant_move = false;
    int count= 0;
    ElType val1, val2, val, val3, val_temp;
    while(!isEmpty(q1) && count < length(q3)){
        // DisplayQueue(q1);
        // DisplayQueue(q2);
        // DisplayQueue(q3);
        // printf("\n");
        if(HEAD(q1) == HEAD(q2)){
            dequeue(&q1, &val1);
            dequeue(&q2, &val2);
            dequeue(&q3, &val3);
            if(val2 == 0){
                printf("%d -> bulat\n", val3);
            }else if(val2 == 1){
                printf("%d -> kotak\n", val3);
            }
            count= 0;
        }else{
            dequeue(&q1, &val);
            dequeue(&q3, &val_temp);
            enqueue(&q1, val);
            enqueue(&q3, val_temp);
            count++;
        }
    }
    printf("%d\n", length(q1));
    return 0;
}
// #include "queuelinked.h"
// #include <stdio.h>
// #include "charmachine.h"
// char currentChar;
// boolean EOP;

// int main()
// {

// 	Queue q_s, q_m, q_id;
// 	CreateQueue(&q_s);
// 	CreateQueue(&q_m);
// 	CreateQueue(&q_id);
// 	int N = 0;
// 	START();
// 	boolean switchSides = false;
// 	while (!EOP)
// 	{
// 		if (currentChar == ',')
// 		{
// 			switchSides = true;
// 			for (int i = 1; i <= N; i++)
// 			{
// 				enqueue(&q_id, i);
// 			}
// 		}
// 		if (!switchSides)
// 		{
// 			if (currentChar == 'B')
// 			{
// 				enqueue(&q_m, 0);
// 			}
// 			if (currentChar == 'K')
// 			{
// 				enqueue(&q_m, 1);
// 			}
// 			N++;
// 		}
// 		else
// 		{
// 			if (currentChar == 'B')
// 			{
// 				enqueue(&q_s, 0);
// 			}
// 			if (currentChar == 'K')
// 			{
// 				enqueue(&q_s, 1);
// 			}
// 		}
// 		ADV();
// 	}
// 	int id, trash1, trash2;
// 	int first_id = HEAD(q_m);
// 	int i = 0;
// 	while (!isEmpty(q_s) && i < length(q_id))
// 	{
// 		if (HEAD(q_s) == HEAD(q_m))
// 		{
// 			dequeue(&q_s, &trash1);
// 			dequeue(&q_m, &trash2);
// 			dequeue(&q_id, &id);
// 			if (trash1 == 0)
// 			{
// 				printf("%d -> bulat\n", id);
// 			}
// 			else
// 			{
// 				printf("%d -> kotak\n", id);
// 			}
// 			i = 0;
// 		}
// 		else
// 		{
// 			i++;
// 			dequeue(&q_m, &trash2);
// 			dequeue(&q_id, &id);
// 			enqueue(&q_m, trash2);
// 			enqueue(&q_id, id);
// 		}
// 	}

// 	printf("%d\n", length(q_m));

// 	return 0;
// }